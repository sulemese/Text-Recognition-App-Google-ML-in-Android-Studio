package com.example.imagetotextconverter;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.github.dhaval2404.imagepicker.ImagePicker;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.io.IOException;
import java.time.Instant;


//MainActivity sınıfı oluşturulur ve AppCompatActivity sınıfından miras alır.
// Bu sınıf, uygulamanın ana etkinliğini temsil eder.
public class MainActivity extends AppCompatActivity {

    //Sınıf içinde kullanılacak değişkenler ve öğeler tanımlanır
    ImageView clear,getImage,copy; //clear, getImage, ve copy, XML dosyasındaki ImageView öğelerine atıfta bulunan ImageView türünde nesnelerdir.
    EditText recgText; //XML dosyasındaki EditText öğesine atıfta bulunan EditText türünde bir nesnedir.
    Uri imageUri; //, seçilen görüntünün URI'sini (Uniform Resource Identifier - Birim Kaynak Tanımlayıcı) saklayan bir Uri nesnesidir.

    TextRecognizer textRecognizer;

    //onCreate yöntemi, etkinlik başlatıldığında otomatik olarak çağrılır:
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);  // üst sınıfın onCreate yöntemi çağrılır.
        setContentView(R.layout.activity_main); //etkinlik için kullanılacak düzen (layout) belirtilir

        //Ardından, XML dosyasındaki öğeler, kod içindeki nesnelere bağlanır.
        // findViewById yöntemi kullanılarak XML'den gelen öğeler, Java kodundaki değişkenlere atılır.
        clear = findViewById(R.id.clear);
        getImage = findViewById(R.id.getImage);
        copy = findViewById(R.id.copy);
        recgText = findViewById(R.id.recgText);
        textRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);





        //getImage düğmesine bir tıklama olayı dinleyicisi eklenir.
        // Bu, ImagePicker kütüphanesi kullanılarak bir resim seçim işlemi başlatır:
        //ImagePicker, kullanıcıların galeriden veya kamera ile resim seçmelerini veya çekmelerini kolaylaştıran bir Android kütüphanesidir.
        //Temel amacı, uygulama geliştiricilerine bu işlemleri basitleştirmek ve kullanıcı dostu bir arayüz sunmaktır.
        getImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //ImagePicker kütüphanesi, görüntü seçimi işlemini yönetir.
                //crop, compress, ve maxResultSize gibi çeşitli seçeneklerle özelleştirilebilir.
                ImagePicker.with(MainActivity.this)
                        .crop()	    			//Crop image(Optional), Check Customization for more option
                        .compress(1024)			//Final image size will be less than 1 MB(Optional)
                        .maxResultSize(1080, 1080)	//Final image resolution will be less than 1080 x 1080(Optional)
                        .start();
            }
        });


        copy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = recgText.getText().toString();
                if(text.isEmpty())
                {
                    Toast.makeText(MainActivity.this,"There is no text to copy",Toast.LENGTH_SHORT).show();
                }
                else
                {
                    ClipboardManager clipboardManager = (ClipboardManager) getSystemService(MainActivity.this.CLIPBOARD_SERVICE);
                    ClipData clipData = ClipData.newPlainText("Data",recgText.getText().toString());
                    clipboardManager.setPrimaryClip(clipData);
                    Toast.makeText(MainActivity.this,"Text copy to Clipboard",Toast.LENGTH_SHORT).show();
                }
            }
        });

        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text=recgText.getText().toString();
                if(text.isEmpty())
                {
                    Toast.makeText(MainActivity.this,"There is no text to clear",Toast.LENGTH_SHORT).show();
                }
                else
                {
                   recgText.setText("");
                }
            }
        });
    }





    //Son olarak, onActivityResult yöntemi, resim seçim işlemi tamamlandığında çağrılır
    // ve seçilen resmin URI'si alınır ve bir bildirim görüntülenir:
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        //resultCode, resim seçim işleminin sonucunu gösterir.
        // Eğer işlem başarılıysa (Activity.RESULT_OK), seçilen resmin URI'si alınır ve bir bildirim görüntülenir.

        if(resultCode == Activity.RESULT_OK)
        {
            if(data!=null)
            {
                imageUri = data.getData();
                Toast.makeText(this, "image selected", Toast.LENGTH_SHORT).show();

                recognizeText();
            }
        }
        //// Eğer işlem başarısızsa, bir hata bildirimi görüntülenir.
        else
        {
            Toast.makeText(this, "image not selected", Toast.LENGTH_SHORT).show();
        }
    }

    private void recognizeText()
    {
        if(imageUri != null)
        {
            try {
                InputImage inputImage = InputImage.fromFilePath(MainActivity.this,imageUri);

                Task<Text> result = textRecognizer.process(inputImage)
                        .addOnSuccessListener(new OnSuccessListener<Text>() {
                            @Override
                            public void onSuccess(Text text) {

                                String recognizeText = text.getText();
                                recgText.setText(recognizeText);
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(MainActivity.this,e.getMessage(),Toast.LENGTH_SHORT).show();
                            }
                        });
            }
            catch (IOException e) {
                throw new RuntimeException(e);
            }

        }

    }
}