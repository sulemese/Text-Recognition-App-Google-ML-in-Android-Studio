package com.example.imagetotextconverter;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;


//SplashScreenActivity sınıfı oluşturulur ve AppCompatActivity sınıfından miras alır.
//Bu sınıf, başlangıç ekranı olarak kullanılan aktiviteyi temsil eder.
public class SplashScreenActivity extends AppCompatActivity
{

    //onCreate yöntemi, aktivite başlatıldığında otomatik olarak çağrılır:
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_splash_screen) ile etkinlik için kullanılacak düzen (layout) belirtilir.
        //Bu, başlangıç ekranı için tasarlanmış bir XML dosyasına işaret eder.
        setContentView(R.layout.activity_splash_screen);


        getSupportActionBar().hide(); //Image To Text Converter yazılı oluşturduğumuz ActionBarı SplashScreen Ekranında gizler.

        //Bu kod, bir başlangıç ekranı (splash screen) gösterir ve belirli bir süre sonra başka bir aktiviteye geçiş yapar.
        // Genellikle uygulamanın başlangıcında marka logosu veya hoş geldiniz mesajlarını göstermek için kullanılır.
        //Ardından, bir Handler kullanılarak belirli bir süre boyunca
        //başka bir aktiviteye geçiş yapılmasını sağlayan işlem başlatılır:
        //new Handler().postDelayed ile belirli bir süre boyunca çalışacak bir işlem oluşturulur.
        //Bu, belirli bir gecikme sonunda işletilir.
        new Handler().postDelayed(new Runnable()
        {
            @Override
            public void run()
            {

                //Intent sınıfı kullanılarak SplashScreenActivity den MainActivity ye geçiş yapılacak bir niyet (intent) oluşturulur.
                Intent intent = new Intent(SplashScreenActivity.this,MainActivity.class);
                //startActivity(intent) ile belirtilen niyet ile yeni aktivite başlatılır.
                startActivity(intent);
                //finish() ile SplashScreenActivity sonlandırılır, böylece kullanıcı geri dönemez.
                finish();

            }
        },2000);




    }
}